/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_part2;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 27681
 */
public class TaskClass { 
  // Arrays to store task details
    private static List<String> developers = new ArrayList<>();
    private static List<String> taskNames = new ArrayList<>();
    private static List<String> taskIds = new ArrayList<>();
    private static List<Integer> taskDurations = new ArrayList<>();
    private static List<String> taskStatuses = new ArrayList<>();
  
    
        
    
    public static void Welcome(){
        
       //Display a welcome message 
        JOptionPane.showMessageDialog(null,"Welcome to EasyKanban");
          
        
        int option;
       //Display the menu until the user chooses to quit
        do{
            String menu = "1)Add tasks\n2) Show report\n3) Display tasks with status 'done'\n4)Display task with longest duration\n5)Search task by name\n6) Search tasks by developer\n7)Delete task by name\n8) Quit";  

           
           
           
            String input = JOptionPane.showInputDialog(menu);

            
            option = Integer.parseInt(input);
            
            switch (option){
                case 1:
                 //Call the method to add tasks
                    addTasks();
                    break;
                case 2:
                  //Display full report
                    displayFullReport();
                    break;
                case 3:
                  //Display tasks with status 'done'
                    displayTasksWithStatusDone();
                    break;
                case 4:
                    //Display task with the longest duration
                    displayTaskWithLongestDuration();
                    break;
                case 5:
                    //Search task by name
                    searchTaskByName();
                    break;
                case 6:
                    //Search tasks by developer
                    searchTasksByDeveloper();
                    break;
                case 7:
                    //Delete task by name
                    deleteTaskByName();
                    break;
                case 8:
                    //Exit message
                    JOptionPane.showMessageDialog(null,"GoodBye!");
                default:
                    JOptionPane.showMessageDialog(null,"Invalid option.Please choose a valid option.");
            }
        }while(option != 8);
    }

private static void addTasks() {
   
   //Prompt the user for the number of tasks to add 
    String input = JOptionPane.showInputDialog(null,"Enter the number of tasks you wish to add:");
    int numTasks = Integer.parseInt(input);
    int totalHours = 0;
    StringBuilder report = new StringBuilder();
    
    //loop to add each task
    for(int i = 0;i < numTasks; i++) {
        
        String taskName = JOptionPane.showInputDialog("Enter Task Name:");
        String taskDescription;
       
        
        //Validate task description length
        while(true) {
            taskDescription = JOptionPane.showInputDialog("Enter Task Description(max 50 characters)");
            if(taskDescription.length() <= 50) {
                JOptionPane.showMessageDialog(null,"Task successfully captured");
                break;
            }else{
                JOptionPane.showMessageDialog(null,"Please enter a task description of less than 50 characters");
                
            }
        }
        String developerDetails;
       
        //Validate developer details format
        while(true){
            developerDetails = JOptionPane.showInputDialog("Enter Developer name: ");
    
            String[] developerNameParts = developerDetails.split(" ");
                   if ( developerNameParts.length == 2 && developerNameParts[0].length() > 0 && developerNameParts[1].length() > 0 ) {
  
            break;
       }else{
           JOptionPane.showMessageDialog(null, "Please enter valid details");
       
         }
        }
        
        
        //Prompt for task duration
        int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter Task Duration (hours):"));
        String[] developerNameParts = developerDetails.split(" ");
      
        // Generate taskID
        String taskId = (taskName.substring(0,2) + ":" + i + ":" + developerNameParts[1].substring(developerNameParts[1].length() -3)).toUpperCase();
  
      
       //Prompt for task status 
        String[] statusOptions = {"TO DO", "DOING", "DONE"};
        int statusIndex = JOptionPane.showOptionDialog(null,"Please select task status", "Task Status",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, statusOptions, statusOptions[0]);
        String taskStatus = statusOptions[statusIndex];
        
  
        //Append task details to the report
 report.append("Task Status: ").append(taskStatus).append("\n");
 report.append("Developer Details: ").append(developerDetails).append("\n");
 report.append("Task Number: ").append(i).append("\n");
 report.append("Task Name:").append(taskName).append("\n");
 report.append("Task Description: ").append(taskDescription).append("\n");
 report.append("Task ID: ").append(taskId).append("\n");
 report.append("Duration:").append(taskDuration).append("hours\n\n");
 
 //Add task details to arrays
 developers.add(developerDetails);
 taskNames.add(taskName);
 taskIds.add(taskId);
 taskDurations.add(taskDuration);
 taskStatuses.add(taskStatus);
 
//Add task duration to the total hours
 totalHours += taskDuration;
                                 
                                 
     
    } 
    
    //Display the accumulated report and total hours
    JOptionPane.showMessageDialog(null, report.toString());
    JOptionPane.showMessageDialog(null,"Total hours: " + totalHours);
}
   private static void displayFullReport() {
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < taskNames.size(); i++) {
            report.append("Task Status: ").append(taskStatuses.get(i)).append("\n");
            report.append("Developer Details: ").append(developers.get(i)).append("\n");
            report.append("Task Number: ").append(i).append("\n");
            report.append("Task Name: ").append(taskNames.get(i)).append("\n");
            report.append("Task ID: ").append(taskIds.get(i)).append("\n");
            report.append("Duration: ").append(taskDurations.get(i)).append(" hours\n\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
   }
        private static void displayTasksWithStatusDone() {
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskStatuses.get(i).equalsIgnoreCase("DONE")) {
                report.append("Developer: ").append(developers.get(i)).append("\n");
                report.append("Task Name: ").append(taskNames.get(i)).append("\n");
                report.append("Task Duration: ").append(taskDurations.get(i)).append(" hours\n\n");
            }
        }
        JOptionPane.showMessageDialog(null, report.toString());
        }
       private static void displayTaskWithLongestDuration() {
        if (taskDurations.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks available.");
            return;
        }
        int maxDurationIndex = 0;
        for (int i = 1; i < taskDurations.size(); i++) {

            if (taskDurations.get(i) > taskDurations.get(maxDurationIndex)) {
                maxDurationIndex = i;
            }
        }
             StringBuilder report = new StringBuilder();
        report.append("Developer: ").append(developers.get(maxDurationIndex)).append("\n");
        report.append("Task Duration: ").append(taskDurations.get(maxDurationIndex)).append(" hours\n");
        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter Task Name to search:");
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                report.append("Task Name: ").append(taskNames.get(i)).append("\n");
                report.append("Developer: ").append(developers.get(i)).append("\n");
                report.append("Task Status: ").append(taskStatuses.get(i)).append("\n\n");
            }
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void searchTasksByDeveloper() {
        String developerName = JOptionPane.showInputDialog("Enter Developer Name to search tasks:");
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equalsIgnoreCase(developerName)) {
                report.append("Task Name: ").append(taskNames.get(i)).append("\n");
                report.append("Task Status: ").append(taskStatuses.get(i)).append("\n\n");
            }
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void deleteTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter Task Name to delete:");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                developers.remove(i);
                taskNames.remove(i);
                taskIds.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                JOptionPane.showMessageDialog(null, "Task deleted successfully.");
            }
        }
    }
}

            
    