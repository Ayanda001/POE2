/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 * Click to githubhttps://github.com/Ayanda001/PROG
 */
package poe_part2;
import java.util.Scanner; 
import javax.swing.JOptionPane;
import javax.swing.JDialog;
/**
 *
 * @author RC_Student_lab
 */
public class POE_Part1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
        JDialog window = new JDialog();
        window.setAlwaysOnTop(true);
        // TODO code application logic here
           Scanner scanner = new Scanner(System.in);
        boolean registrationSuccess = false;
        boolean loginSuccess = false;
        //boolean welcome();
        
        
            registrationSuccess = Registration.register();
            if(registrationSuccess == true){
                
                            loginSuccess = Login.login();

            }
        
      
            if (loginSuccess){

                TaskClass.Welcome();
            }
           
    }
}
    
    

